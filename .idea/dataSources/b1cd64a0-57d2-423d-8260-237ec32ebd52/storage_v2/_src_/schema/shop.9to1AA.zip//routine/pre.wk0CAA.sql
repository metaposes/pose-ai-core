CREATE PROCEDURE pre()
  begin
declare i DOUBLE;		
set i=1;
while i<9999 do		
	insert into item (product_id,score) values('1',i); 
set i=i+1;		
end while;
end;

